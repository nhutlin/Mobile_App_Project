package com.example.uit_project;

import android.widget.RelativeLayout;

public class GlobalVar {
    public static String baseUrl = "https://uiot.ixxc.dev/";
//    public static String signUpUrl = baseUrl + "auth/realms/master/login-actions/";
//    public static String tokenUrl = baseUrl + "auth/realms/master/protocol/openid-connect/token";
//    public static String resetUrl = baseUrl + "auth/realms/master/account/password";
    public static String LOG_TAG = "API LOG";

    public static LanguageManager manager;
    public static RelativeLayout view;

}